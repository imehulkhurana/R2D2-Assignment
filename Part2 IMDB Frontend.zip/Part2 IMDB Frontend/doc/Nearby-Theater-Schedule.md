## Update theater location
1. Get theater list from yahoo
2. Get theater Geo location by yahoo theater address from google

## Get nearby theater schedule
1. Get User Geo location from google
2. Compute nearby theater
3. get schedule from nearby theater