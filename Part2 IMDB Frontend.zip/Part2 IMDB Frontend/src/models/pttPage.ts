import Article from './article';
export default class PttPage {
    pageIndex: number
    url: string
    articles : Article[]
}