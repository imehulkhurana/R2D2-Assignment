export default class Article {
    yahooId?: number
    title?: string
    push?: string
    url?: string
    date?: string
    author?: string
}