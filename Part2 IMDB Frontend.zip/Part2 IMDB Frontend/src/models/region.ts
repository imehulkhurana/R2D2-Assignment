export default class Region {
    name : string
    regionId : string
}
