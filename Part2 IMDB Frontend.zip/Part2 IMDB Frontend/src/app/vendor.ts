import 'react';
import 'react-router';
import 'react-dom';
import 'react-tap-event-plugin';
import 'react-swipeable-views';
import 'moment';
import 'isomorphic-fetch';


//css
import 'bootstrap/dist/css/bootstrap.min.css'
import 'hint.css/hint.min.css'