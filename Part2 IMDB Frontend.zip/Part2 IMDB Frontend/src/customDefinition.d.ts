declare module NodeJS  {
    interface Global {
        navigator: any,
        document: any
    }
}